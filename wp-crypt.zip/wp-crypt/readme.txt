=== WpCrypt ===
Contributors: bruno.sousa
Donate link: www.emancipa.net/doe
Tags: encryption, security, password, hash, hashes, sha1, sha2, AES
Requires at least: 3.3
Tested up to: 3.5.1
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allow users to change password encryption method to SHA1, SHA2, AES Rijndael and more...

== Description ==

Allow users to change password encryption method to SHA1, SHA2, AES Rijndael and more...

== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to user profile page and change your hash.

== Frequently asked questions ==

= Why should people be careful using WpCrypt? =

WpCrypt plugin was made to change password hashes stored in your DB from user profile page.

== Screenshots ==

1. http://oi44.tinypic.com/2qlvejr.jpg